<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_US 1</name>
   <tag></tag>
   <elementGuidId>baed272b-f023-4873-8309-819a8d257010</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.country-display-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div[2]/div[2]/div/span/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>613dce3d-f2a4-469e-9048-88540afc39e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>country-display-text</value>
      <webElementGuid>86923e88-8271-48a1-b08c-b3c5f6f705e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
              US +1
            </value>
      <webElementGuid>fc1e52a9-5c81-4f56-a2d0-a838ed4969e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-section a-spacing-base moa-single-claim-container&quot;]/div[@class=&quot;a-section a-spacing-none moa-single-claim-input-container&quot;]/div[@class=&quot;a-section country-picker&quot;]/span[@class=&quot;a-declarative&quot;]/span[@class=&quot;country-display-text&quot;]</value>
      <webElementGuid>e2b39e69-8915-4e89-8e8c-7608e9872dd2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div[2]/div[2]/div/span/span</value>
      <webElementGuid>8aa62f0a-6f94-474c-bbd1-181e1bd70548</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/span/span</value>
      <webElementGuid>d91f69e1-acde-4359-a00b-8c0170ac18d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
              US +1
            ' or . = '
              US +1
            ')]</value>
      <webElementGuid>b021079f-0033-48e3-a0cd-704af0120fe1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
